#include "RopeTextBuffer.h"

// ----------------- DoublyLinkedList -----------------
Rope::Rope() {
    // TODO
}

Rope::~Rope() {
    // TODO
}

// TODO: implement other methods of DoublyLinkedList

// ----------------- RopeTextBuffer -----------------
RopeTextBuffer::RopeTextBuffer() {
    // TODO
}

RopeTextBuffer::~RopeTextBuffer() {
    // TODO
}

// TODO: implement other methods of TextBuffer

// ----------------- HistoryManager -----------------
RopeTextBuffer::HistoryManager::HistoryManager() {
    // TODO
}

RopeTextBuffer::HistoryManager::~HistoryManager() {
    // TODO
}

//TODO: implement other methods of HistoryManager
